"""
DOCSTRINGS FOR pycmplot/plotting/linear.py AND pycmplot/plotting/circular.py
==============================================================================
Instructions
------------
Paste each docstring into the matching function body.

Bugs fixed vs. the existing partial docstrings
-----------------------------------------------
* ``plot_linear`` — ``sumstats_loaded`` documented as ``list``; actual
  type is ``dict`` (output of
  ``get_sumstats_and_merged_sector_list``).
* ``plot_linear`` — ``hits_table`` and ``label_col`` descriptions were
  internally inconsistent (the function passes ``hits_table`` to
  ``plot_linearm`` as ``annot_df``).
* ``plot_linear`` — ``signif_lines`` documented as ``Optional[dict]``
  but is ``list[dict]``.
* ``plot_circosm`` — several parameters had no description at all.
"""

# ═══════════════════════════════════════════════════════════════════════════
# plotting/linear.py
# ═══════════════════════════════════════════════════════════════════════════

# ── Module docstring ──────────────────────────────────────────────────────────

LINEAR_MODULE = '''"""
pycmplot.plotting.linear
========================

Multi-track stacked linear Manhattan plot.

The module exposes two public functions:

* :func:`plot_linear` — the user-facing entry point.  Accepts the
  ``sumstats_loaded`` dict produced by
  :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`, resolves
  output paths, and delegates rendering to :func:`plot_linearm`.
* :func:`plot_linearm` — the core rendering engine.  Accepts a list of
  DataFrames and a fully resolved set of plotting parameters, builds the
  matplotlib figure, draws all tracks, and saves the file.

Internal helpers:

* :func:`_cluster_annotations_by_chr` — groups annotation points that
  are close together on the same chromosome so label-spreading can be
  applied per cluster rather than globally.
* :func:`_draw_annotation_arrows` — places angled
  :class:`~matplotlib.patches.FancyArrowPatch` arrows from spread gene
  labels down to their corresponding signal positions.
"""'''


# ── _cluster_annotations_by_chr ───────────────────────────────────────────────

CLUSTER_ANNOTS = '''"""Cluster annotation points within each chromosome by genomic proximity.

Groups rows of *annot_df* on the same chromosome into clusters such that
consecutive points within *window_size* base-pairs are placed in the same
cluster.  Clusters are used by :func:`_draw_annotation_arrows` to
determine independent label-spreading regions.

Parameters
----------
annot_df : pandas.DataFrame
    Annotation DataFrame containing at least *chr_col* and *x_col*
    (cumulative x-axis position).
chr_col : str, optional
    Name of the chromosome column.  Default ``'CHR'``.
x_col : str, optional
    Name of the cumulative x-axis position column.  Default ``'x'``.
window_size : float, optional
    Maximum gap in cumulative x-axis units between two points that should
    be considered part of the same cluster.  Default ``50e6`` (50 Mb).

Returns
-------
list of list
    Each inner list contains the integer index values of *annot_df* rows
    that form one cluster.
"""'''


# ── _draw_annotation_arrows ───────────────────────────────────────────────────

DRAW_ARROWS = '''"""Draw angled arrow annotations from gene-label text to signal positions.

For each significant locus in *annot_df*, places the gene/SNP label text
above the track and connects it to the corresponding scatter-plot point
with a curved :class:`~matplotlib.patches.FancyArrowPatch` arrow.  Labels
within the same chromosome are spread horizontally to avoid overlap; the
arrow curvature direction (clockwise/counter-clockwise arc) is determined
automatically from the sign of the horizontal displacement.

The function operates on *ax* (the annotation sub-panel at the top of the
figure) and returns ``None`` — it modifies the axes in place.

Parameters
----------
ax : matplotlib.axes.Axes
    The annotation axes (top sub-panel, invisible background).
annot_df : pandas.DataFrame
    Lead-SNP annotation DataFrame with columns *chr_col*, ``'x'``
    (cumulative x-axis position), and *label_col*.
chr_col : str
    Name of the chromosome column.
label_col : str
    Name of the column containing the text labels (gene symbols or rsIDs).
offsets : dict
    Mapping of ``chromosome → cumulative_x_start`` as computed from the
    main track data.
chr_max : dict
    Mapping of ``chromosome → max_position`` for each chromosome.
spread_width : float, optional
    Horizontal spacing between adjacent labels within a cluster.
    Default ``60e6`` (60 Mb).
y_tip : float, optional
    y-coordinate (in axes data units, 0–1) of the arrowhead tip.
    Default ``0.0``.
y_text : float, optional
    y-coordinate of the label text anchor.  Default ``0.55``.
"""'''


# ── plot_linearm ───────────────────────────────────────────────────────────────

PLOT_LINEARM = '''"""Core rendering engine for the multi-track stacked linear Manhattan plot.

Builds a :class:`~matplotlib.figure.Figure` with one annotation sub-panel
at the top (for gene/SNP labels and connecting arrows) and *n* data tracks
below it, one per element of *tracks*.  All tracks share the same
cumulative x-axis.

This function is called by the higher-level :func:`plot_linear` wrapper and
is not normally invoked directly.

Parameters
----------
tracks : list of pandas.DataFrame
    One DataFrame per GWAS trait.  Each must have columns ``CHR``,
    ``POS``, ``P``, and ``logP`` (when *logp* is ``True``).  The
    DataFrames are pre-processed internally (chromosome normalisation,
    highlighting, cumulative x-axis computation).
track_labels : list of str, optional
    Y-axis label for each track, in the same order as *tracks*.
    Defaults to ``['Track 1', 'Track 2', …]``.
annot_df : pandas.DataFrame, optional
    Annotation DataFrame (typically the hits summary table).  Must have
    columns ``CHR``, ``POS``, and *label_col*.  When provided, a dashed
    vertical guide line is drawn through every annotated position across
    all tracks, and gene/SNP label arrows are drawn in the top sub-panel.
highlight : bool, optional
    If ``True``, variants within 500 kb of a lead SNP (as determined by
    :func:`~pycmplot.stats.get_highlight_snps`) are rendered in brown.
    Default ``False``.
highlight_thresh : float, optional
    P-value threshold used for locus highlighting.  Default ``5e-8``.
trim_pval : float, optional
    Reserved for future use; trimming is currently handled upstream in
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.
logp : bool, optional
    If ``True``, plot –log₁₀(p) on the y-axis; requires a ``logP``
    column in each DataFrame.  Default ``True``.
label_col : str, optional
    Column in *annot_df* to use as annotation text labels (e.g.
    ``'top_gene'``).  Default ``'label'``.
chr_order : list of str, optional
    Chromosome display order.  Defaults to
    :data:`~pycmplot.constants.CHROM_ORDER` (autosomes 1–22, X, Y, MT).
chr_spacing : float, optional
    Gap in base-pairs inserted between consecutive chromosomes on the
    x-axis.  Default ``9e6``.
track_heights : list of float, optional
    Relative height ratios for the gridspec rows.  The first element
    controls the annotation sub-panel; subsequent elements control the
    data tracks.  When ``None``, the annotation panel is given a weight
    of 1 and each data track a weight of 3.
track_spacing : float, optional
    Vertical ``hspace`` between tracks as a fraction of average track
    height.  Default ``0.10``.
point_size : float, optional
    Scatter-plot point size passed to :func:`matplotlib.axes.Axes.scatter`.
    Default ``5``.
colors : list of str, optional
    Two alternating matplotlib colour strings for even/odd chromosomes.
    Default ``['steelblue', 'orange']``.
sig_lines : list of dict, optional
    One ``{'genome': float, 'suggestive': float}`` dict per track.
    ``'genome'`` values are drawn as red dashed lines; ``'suggestive'``
    values as grey dashed lines.
plt_name : str, optional
    Full output file path (including extension).  When provided the figure
    is saved to disk.
no_track_labels : bool, optional
    If ``True``, track y-axis labels are suppressed.  Default ``False``.
fig_format : str, optional
    Output image format (``'png'``, ``'pdf'``, ``'svg'``).  Inferred
    from *plt_name*'s extension when ``None``.
dpi : int, optional
    Output resolution in dots per inch.  Default ``300``.
figsize : tuple of (float, float), optional
    Figure dimensions ``(width, height)`` in inches.  Default ``(15, 9)``.

Returns
-------
fig : matplotlib.figure.Figure
    The completed figure.
axes : list of matplotlib.axes.Axes
    All axes in the figure: ``axes[0]`` is the annotation sub-panel;
    ``axes[1:]`` are the data-track axes in the same order as *tracks*.

See Also
--------
plot_linear :
    User-facing wrapper that extracts DataFrames from the
    ``sumstats_loaded`` dict and resolves output paths before calling
    this function.
_draw_annotation_arrows :
    Called internally to render gene/SNP label arrows in ``axes[0]``.
pycmplot.stats.get_highlight_snps :
    Called internally when *highlight* is ``True``.
"""'''


# ── plot_linear ───────────────────────────────────────────────────────────────

PLOT_LINEAR = '''"""Generate a multi-track stacked linear Manhattan plot.

This is the primary user-facing entry point for linear Manhattan plots.
It extracts DataFrames and labels from *sumstats_loaded*, resolves output
file paths, then delegates all rendering to :func:`plot_linearm`.

Parameters
----------
sumstats_loaded : dict
    Mapping of ``label → [DataFrame, n_chroms]`` as returned by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.  One
    track is created per key; the DataFrames must have canonical columns
    ``CHR``, ``POS``, ``P``, and ``logP`` (when *logp* is ``True``).
trim_pval : float, optional
    Reserved; trimming is applied upstream.  Default ``None``.
track_heights : list of float, optional
    Comma-parsed relative track heights (e.g. ``[2.0, 2.0, 1.5]``).
    Passed directly to :func:`plot_linearm` as the gridspec height
    ratios for the data tracks.  When ``None``, all tracks are equal.
logp : bool, optional
    Plot –log₁₀(p) on the y-axis.  Default ``False``.
point_size : float, optional
    Scatter-plot point size.  Default uses :func:`plot_linearm`'s
    default (``5``).
highlight : bool, optional
    Render significant-locus variants in brown.  Default ``False``.
highlight_thresh : float, optional
    P-value threshold for locus highlighting.  Default ``5e-8``.
hits_table : pandas.DataFrame, optional
    Annotation DataFrame (hits summary table from
    :func:`~pycmplot.annotation.get_hits_summary_table`).  Must contain
    columns ``CHR``, ``POS``, and *label_col*.  Passed to
    :func:`plot_linearm` as ``annot_df``.  ``None`` or an empty
    DataFrame suppresses annotations.
label_col : str, optional
    Column in *hits_table* to use as annotation text (e.g.
    ``'top_gene'``).  Default ``None`` (falls back to :func:`plot_linearm`
    default ``'label'``).
chr_spacing : float, optional
    Horizontal gap between chromosomes in base-pairs.  Default ``9e6``.
track_spacing : float, optional
    Vertical space between tracks as a fraction of average track height.
    Default ``0.10``.
colors : list of str, optional
    Two alternating chromosome colours.  Default ``['steelblue', 'silver']``.
signif_lines : list of dict, optional
    One ``{'genome': float, 'suggestive': float}`` dict per track, in
    the same order as *sumstats_loaded*.  Produced by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.
plot_title : str, optional
    Human-readable title used as the output file-name stem.  Passed to
    :func:`~pycmplot.io.get_output_paths`.
no_track_labels : bool, optional
    Suppress track y-axis labels.  Default ``False``.
dpi : int, optional
    Output resolution in dots per inch.  Default ``300``.
output_format : str, optional
    Image format (``'png'``, ``'pdf'``, ``'svg'``, ``'jpg'``).
    Default ``'png'``.
output_dir : str or pathlib.Path, optional
    Directory in which to save the output files.  Default ``'.'``.
figsize : tuple of (float, float), optional
    Figure dimensions ``(width, height)`` in inches.  Default ``(15, 9)``.

Returns
-------
fig : matplotlib.figure.Figure
    The completed figure.
axes : list of matplotlib.axes.Axes
    All axes: ``axes[0]`` is the annotation sub-panel; ``axes[1:]``
    are the per-track data axes.

See Also
--------
plot_linearm :
    The underlying rendering engine called by this function.
pycmplot.io.get_sumstats_and_merged_sector_list :
    Produces *sumstats_loaded* and *signif_lines*.

Examples
--------
>>> from pycmplot.plotting.linear import plot_linear
>>> fig, axes = plot_linear(
...     sumstats_loaded=loaded,
...     logp=True,
...     highlight=True,
...     hits_table=hits,
...     label_col="top_gene",
...     signif_lines=sig_lines,
...     plot_title="RBC_Traits",
...     output_dir="./results",
... )
"""'''


# ═══════════════════════════════════════════════════════════════════════════
# plotting/circular.py
# ═══════════════════════════════════════════════════════════════════════════

# ── Module docstring ──────────────────────────────────────────────────────────

CIRCULAR_MODULE = '''"""
pycmplot.plotting.circular
===========================

Circos-style multi-track circular Manhattan plot.

The module exposes two public functions and one internal per-sector helper:

* :func:`plot_circular` — user-facing entry point.  Configures the
  :class:`pycirclize.Circos` canvas, computes track radii, iterates over
  sectors and tracks, renders gene/SNP annotations, and saves the figure.
* :func:`compute_track_radii_dict` — divides the radial space between
  *r_min* and *r_max* into *n_tracks* evenly-spaced, padded bands and
  returns their ``(r_start, r_end)`` limits.
* :func:`plot_circosm` — internal per-sector renderer called once per
  ``(sector, sumstat)`` pair inside the main loop of :func:`plot_circular`.
  Mutates the :class:`pycirclize.Sector` object in place and returns
  ``None``.
"""'''


# ── compute_track_radii_dict ──────────────────────────────────────────────────

COMPUTE_RADII = '''"""Compute ``(r_start, r_end)`` tuples for *n_tracks* evenly-spaced radial bands.

Divides the usable radial space between *r_min* and *r_max* into
*n_tracks* bands of equal height, separated by gaps of *pad* units.  The
tracks are ordered from innermost (``'track_1'``) to outermost
(``'track_n'``).

Parameters
----------
n_tracks : int
    Number of data tracks to accommodate.
r_min : float, optional
    Inner boundary of the full plotting area (as a percentage of the
    figure radius).  Default ``20``.
r_max : float, optional
    Outer boundary of the full plotting area.  Default ``100``.
pad : float, optional
    Gap in the same radius units between consecutive tracks.  Default ``1``.
annotate : bool, optional
    If ``True``, an extra slot is reserved for the annotation ring by
    incrementing *n_tracks* before computing heights.  The extra slot
    is always placed at the outermost position.  Default ``False``.

Returns
-------
dict
    Mapping of ``'track_i' → (r_start, r_end)`` for
    ``i`` in ``1 … n_tracks`` (plus one extra entry when *annotate* is
    ``True``).

Raises
------
ValueError
    If the total padding ``pad × (n_tracks − 1)`` exceeds the available
    radial space ``r_max − r_min``.

Examples
--------
>>> from pycmplot.plotting.circular import compute_track_radii_dict
>>> radii = compute_track_radii_dict(n_tracks=3, r_min=20, r_max=100, pad=2)
>>> list(radii.items())
[('track_1', (20.0, 45.33...)),
 ('track_2', (47.33..., 72.66...)),
 ('track_3', (74.66..., 100.0))]
"""'''


# ── plot_circosm ──────────────────────────────────────────────────────────────

PLOT_CIRCOSM = '''"""Plot one track of summary statistics onto a single pycirclize sector.

This is a low-level internal function called once for every
``(sector, sumstat)`` combination in the :func:`plot_circular` main loop.
It adds a scatter track to *sector* in-place and optionally draws
significance lines, y-axis ticks (on the first chromosome only), and
chromosome labels.  Returns ``None``.

Parameters
----------
sector : pycirclize.Sector
    The pycirclize Sector object representing one chromosome arc.
sector_radius : tuple of (float, float)
    ``(r_start, r_end)`` radial limits for this track within *sector*,
    as returned by :func:`compute_track_radii_dict`.
annotation_r : tuple of (float, float) or None
    Radial limits reserved for the annotation ring.  Passed for context
    but not used directly inside this function.
assoc : pandas.DataFrame, optional
    Full summary statistics DataFrame (all chromosomes).  Filtered to the
    current sector's chromosome internally.  Must have columns ``CHR``,
    ``POS``, ``P``, and ``logP`` (when *logp* is ``True``).
sector_sizes : dict, optional
    Ordered mapping of ``chrom → [min_pos, max_pos]`` as returned by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.  Used to
    identify the first and last sectors for y-axis ticks and track labels.
chrom_label_loc : float or None
    Radial position at which to draw the chromosome label.  Computed in
    :func:`plot_circular` from *chrom_label_side*, *r_min*, and *r_max*.
chrom_label_size : float, optional
    Font size for chromosome labels.  Default ``6``.
track_label_size : float, optional
    Font size for the track (sumstat) label written on the spacer sector.
    Default ``6``.
track_label_orientation : {'vertical', 'horizontal'}, optional
    Orientation of the track label text.  Default ``'vertical'``.
track_index : int, optional
    0-based index of the current sumstat track.  Chromosome labels are
    only drawn on ``track_index == 0`` (or for chromosome X).
    Default ``0``.
assoc_label : str, optional
    Track label text (sumstat name) rendered on the spacer sector.
logp : bool, optional
    If ``True``, use the ``logP`` column for y-values and threshold
    comparisons.  Default ``True``.
signif_line : float, optional
    Y-value at which to draw the genome-wide significance dashed line
    (orange-red).  Default ``5e-8``.
signif_threshold : float, optional
    Significance threshold used for y-axis scaling.  Default ``5e-8``.
suggest_line : float or bool, optional
    Y-value for the suggestive significance dashed line (light blue).
    Pass ``False`` or ``None`` to suppress.  Default ``1e-5``.
suggest_threshold : float, optional
    Suggestive threshold value used for y-axis scaling.  Default ``1e-5``.
highlight : bool, optional
    If ``True``, variants within significant loci (``in_locus == True``
    after :func:`~pycmplot.stats.get_highlight_snps`) are rendered in
    brown.  Default ``False``.
highlight_thresh : float, optional
    P-value threshold passed to
    :func:`~pycmplot.stats.get_highlight_snps` when *highlight* is
    ``True``.  Default ``5e-8``.
colors : list of str, optional
    Two alternating colours for even/odd chromosome numbers.
    Default ``['steelblue', 'orange']``.
no_track_labels : bool, optional
    Suppress the track label on the spacer sector.  Default ``False``.
"""'''


# ── plot_circular ─────────────────────────────────────────────────────────────

PLOT_CIRCULAR = '''"""Generate a multi-track Circos-style circular Manhattan plot.

Sets up a :class:`pycirclize.Circos` canvas with one arc sector per
chromosome, computes radial track extents, and calls :func:`plot_circosm`
once per ``(sector, sumstat)`` pair to populate each track with scatter
data and significance lines.  After all tracks are rendered, gene or SNP
annotations from *hits_table* are added to a dedicated annotation ring,
and a shared y-axis label is placed on the spacer sector.

Parameters
----------
sumstats_loaded : dict
    Mapping of ``label → [DataFrame, n_chroms]`` as returned by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.  One
    radial track is created per key.  The outermost track corresponds to
    the first key after reversal of the radii dict.
sector_sizes : dict, optional
    Ordered mapping of ``chrom → [min_pos, max_pos]`` defining the arc
    length of each chromosome sector.  The last key is expected to be
    ``'Spacer1'`` (automatically added by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`).
signif_lines : list of dict, optional
    One ``{'genome': float, 'suggestive': float}`` dict per track in the
    same order as *sumstats_loaded*, as returned by
    :func:`~pycmplot.io.get_sumstats_and_merged_sector_list`.
logp : bool, optional
    Plot –log₁₀(p) radially.  Default ``False``.
pad : float, optional
    Gap in radius units between consecutive tracks.  Default ``1``.
r_min : float, optional
    Inner radius of the innermost track (as a percentage of the figure
    radius).  Default ``0``.
r_max : float, optional
    Outer radius of the outermost track.  Default ``100``.
annotate : {'SNP', 'GENE'} or falsy, optional
    Annotation content for significant loci.  ``'GENE'`` uses
    ``nearest_upstream_gene`` for genic hits and ``top_gene`` for
    intergenic hits (italic text); ``'SNP'`` uses the ``SNP`` column
    (regular text).  Pass ``None`` or ``False`` to disable annotations.
    Default ``'SNP'``.
chrom_label_side : {'inside', 'outside'}, optional
    Radial position of chromosome labels.  ``'inside'`` places them just
    inside the innermost track; ``'outside'`` places them beyond the
    outermost track.  Default ``'inside'``.
signif_line : float, optional
    Genome-wide significance threshold value for the orange-red dashed
    line.  Default ``5e-8``.
highlight : bool, optional
    Render significant-locus variants in brown.  Default ``False``.
highlight_thresh : float, optional
    P-value threshold for locus highlighting.  Default ``5e-8``.
colors : list of str, optional
    Two alternating chromosome colours.  Default ``['steelblue', 'grey']``.
chrom_label_size : float, optional
    Chromosome label font size.  Default ``6``.
track_label_size : float, optional
    Track (sumstat) label font size.  Default ``6``.
track_label_orientation : {'vertical', 'horizontal'}, optional
    Track label text orientation.  Default ``'vertical'``.
hits_table : pandas.DataFrame, optional
    Hits summary table from
    :func:`~pycmplot.annotation.get_hits_summary_table`.  Required for
    annotations (``annotate`` truthy and ``hits_table`` non-empty).
annotation_size : float, optional
    Font size for annotation labels.  Default ``6``.
highlight_line : bool, optional
    Draw a dashed radial line from the innermost track to the annotation
    ring for each annotated position.  Default ``False``.
plot_title : str, optional
    Text placed in the centre of the circle and used as the output
    file-name stem.
plot_title_size : float, optional
    Font size for the centre title.  Default ``12``.
dpi : int, optional
    Output resolution in dots per inch.  Default ``300``.
output_format : str, optional
    Image format (``'png'``, ``'pdf'``, ``'svg'``, ``'jpg'``).
    Default ``'png'``.
output_dir : str or pathlib.Path, optional
    Output directory.  Default ``'.'``.
no_track_labels : bool, optional
    Suppress track labels on the spacer sector.  Default ``False``.

Returns
-------
matplotlib.figure.Figure
    The completed circular Manhattan figure (also saved to *output_dir*).

See Also
--------
plot_circular is the circular counterpart to
:func:`pycmplot.plotting.linear.plot_linear`.

compute_track_radii_dict :
    Computes the ``(r_start, r_end)`` limits for each track.
plot_circosm :
    Per-sector rendering function called inside the main loop.
pycmplot.io.get_sumstats_and_merged_sector_list :
    Produces *sumstats_loaded*, *sector_sizes*, and *signif_lines*.

Examples
--------
>>> from pycmplot.plotting.circular import plot_circular
>>> fig = plot_circular(
...     sumstats_loaded=loaded,
...     sector_sizes=sectors,
...     signif_lines=sig_lines,
...     logp=True,
...     highlight=True,
...     annotate="GENE",
...     hits_table=hits,
...     plot_title="RBC_Traits",
...     output_dir="./results",
... )
"""'''
